from .src.enigmacrypt import Decryption
from .src.enigmacrypt import Encryption
